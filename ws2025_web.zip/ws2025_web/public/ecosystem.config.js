module.exports = {
	apps: [
		{
			name: "web-test",
			script: "./index.js",
			exec_mode: "fork",
			time: true,
		}
	]
};
