let reservationData = [];
let sortState = { column: "", order: "asc" };

// 예약자 리스트 렌더링 함수
function renderReservations(data) {
    const tbody = document.querySelector("#reservation-table tbody");
    tbody.innerHTML = "";
    data.forEach(item => {
        const row = document.createElement("tr");
        row.innerHTML = `
            <td>${item.name}</td>
            <td>${item.number}</td>
            <td>${item.email}</td>
        `;
        tbody.appendChild(row);
    });
}

// 데이터 필터링: 검색어로 필터링한 데이터를 반환
function filterReservations(query) {
    query = query.toLowerCase();
    return reservationData.filter(item =>
        item.name.toLowerCase().includes(query) ||
        // "number" 필드를 사용합니다.
        item.number.toLowerCase().includes(query) ||
        item.email.toLowerCase().includes(query)
    );
}

// 데이터 정렬: 지정한 컬럼과 order(asc/desc)로 정렬
function sortReservations(data, column) {
    if (!column) return data;
    return data.sort((a, b) => {
        const aVal = a[column].toLowerCase();
        const bVal = b[column].toLowerCase();
        if (aVal < bVal) return sortState.order === "asc" ? -1 : 1;
        if (aVal > bVal) return sortState.order === "asc" ? 1 : -1;
        return 0;
    });
}

// 예약자 데이터 불러오기 (Node.js API 연동)
function loadReservations() {
    fetch("/api/reservations")
        .then(response => response.json())
        .then(data => {
            reservationData = data;
            let filteredData = filterReservations(document.getElementById("search-input").value);
            if (sortState.column) {
                filteredData = sortReservations(filteredData, sortState.column);
            }
            renderReservations(filteredData);
        })
        .catch(error => console.error("예약자 리스트 불러오기 오류:", error));
}

loadReservations();

document.getElementById("search-input").addEventListener("input", e => {
    const query = e.target.value;
    let filteredData = filterReservations(query);
    if (sortState.column) {
        filteredData = sortReservations(filteredData, sortState.column);
    }
    renderReservations(filteredData);
});

document.querySelectorAll("#reservation-table th").forEach(th => {
    th.style.cursor = "pointer";
    th.addEventListener("click", () => {
        const column = th.getAttribute("data-column");
        if (sortState.column === column) {
            sortState.order = sortState.order === "asc" ? "desc" : "asc";
        } else {
            sortState.column = column;
            sortState.order = "asc";
        }
        let filteredData = filterReservations(document.getElementById("search-input").value);
        filteredData = sortReservations(filteredData, column);
        renderReservations(filteredData);
        showFeedback("정렬되었습니다.", "success");
    });
});

document.getElementById("reservation-form").addEventListener("submit", function(e) {
    e.preventDefault();
    const name = document.getElementById("name").value;
    const phone = document.getElementById("phone").value;
    const email = document.getElementById("email").value;
    const data = { name, phone, email };
    // 서버에서는 phone 값을 받아 DB의 number 컬럼에 저장합니다.
    fetch("/api/reservations/add", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data)
    })
        .then(response => response.json())
        .then(result => {
            console.log("예약 추가 결과:", result);
            document.getElementById("reservation-form").reset();
            loadReservations();
            showFeedback("예약이 추가되었습니다.", "success");
        })
        .catch(error => {
            console.error("예약 추가 오류:", error);
            showFeedback("예약 추가에 실패했습니다.", "error");
        });
});

function exportToCSV(data, filename = "reservations.csv") {
    let csv = "이름,전화번호,이메일\n";
    data.forEach(item => {
        csv += `${item.name},${item.number},${item.email}\n`;
    });
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const link = document.createElement("a");
    const url = URL.createObjectURL(blob);
    link.setAttribute("href", url);
    link.setAttribute("download", filename);
    link.style.visibility = "hidden";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
}

function exportToExcel(data, filename = "reservations.xls") {
    let csv = "이름\t전화번호\t이메일\n";
    data.forEach(item => {
        csv += `${item.name}\t${item.number}\t${item.email}\n`;
    });
    const blob = new Blob([csv], { type: "application/vnd.ms-excel" });
    const link = document.createElement("a");
    const url = URL.createObjectURL(blob);
    link.setAttribute("href", url);
    link.setAttribute("download", filename);
    link.style.visibility = "hidden";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
}

document.getElementById("export-csv").addEventListener("click", () => {
    const query = document.getElementById("search-input").value;
    let filteredData = filterReservations(query);
    if (sortState.column) {
        filteredData = sortReservations(filteredData, sortState.column);
    }
    exportToCSV(filteredData);
});

document.getElementById("export-excel").addEventListener("click", () => {
    const query = document.getElementById("search-input").value;
    let filteredData = filterReservations(query);
    if (sortState.column) {
        filteredData = sortReservations(filteredData, sortState.column);
    }
    exportToExcel(filteredData);
});

function showFeedback(message, type) {
    const feedbackDiv = document.getElementById("feedback");
    feedbackDiv.textContent = message;
    feedbackDiv.className = type === "success" ? "feedback-success" : "feedback-error";
    feedbackDiv.style.transition = "none";
    feedbackDiv.style.opacity = "1";
    feedbackDiv.style.display = "block";
    void feedbackDiv.offsetWidth;
    feedbackDiv.style.transition = "opacity 2s ease-out";
    setTimeout(() => {
        feedbackDiv.style.opacity = "0";
        setTimeout(() => {
            feedbackDiv.style.display = "none";
        }, 2000);
    }, 3000);
}

const toggleBtn = document.getElementById("toggle-btn");
const reservationWrapper = document.querySelector(".reservation-wrapper");
let isVisible = false;

toggleBtn.addEventListener("click", () => {
    isVisible = !isVisible;
    if (isVisible) {
        reservationWrapper.style.display = "block";
        toggleBtn.textContent = "❌";
    } else {
        reservationWrapper.style.display = "none";
        toggleBtn.textContent = "📋";
    }
});

const adminExportBtn = document.getElementById("admin-export-btn");
const exportButtonsDiv = document.getElementById("export-buttons");
let exportVisible = false;

adminExportBtn.addEventListener("click", () => {
    exportVisible = !exportVisible;
    exportButtonsDiv.style.display = exportVisible ? "flex" : "none";
});
