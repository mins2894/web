const express = require('express');
const app = express();
const port = process.env.PORT || 12025;

app.set("view engine", "ejs");
app.set("views", `./views`);

app.get('/', (req, res) => {
	res.render('hello');
});

app.listen(port, () => {
	console.log(`ws2025 web test server port : ${port}`);
});
