// server.js
const express = require("express");
const mysql = require("mysql2");
const bodyParser = require("body-parser");
const cors = require("cors");

const app = express();

// 미들웨어 설정
app.use(cors());
app.use(bodyParser.json());
app.use(express.static("public"));

// MySQL 연결 설정 (데이터베이스 이름은 'test')
const connection = mysql.createConnection({
    host: "localhost",
    user: "root",           // 실제 사용자명으로 수정
    password: "1234",           // 실제 비밀번호로 수정
    database: "test"
});

// MySQL 연결 확인
connection.connect(err => {
    if (err) {
        console.error("MySQL 연결 실패:", err);
        return;
    }
    console.log("MySQL 연결 성공");
});
// 예약 목록 조회 API (테이블 이름: reservation)
// 'id' 컬럼이 없으므로 ORDER BY 구문을 제거하거나, 다른 컬럼으로 정렬합니다.
app.get("/api/reservations", (req, res) => {
    const query = "SELECT * FROM reservation"; // ORDER BY id DESC 제거
    connection.query(query, (err, results) => {
        if (err) {
            console.error(err);
            res.status(500).send("DB 쿼리 오류");
            return;
        }
        res.json(results);
    });
});

// 예약 추가 API (컬럼: name, number, email)
app.post("/api/reservations/add", (req, res) => {
    const { name, phone, email } = req.body;
    // 여기서 입력받은 "phone"을 DB의 "number" 컬럼에 저장합니다.
    const query = "INSERT INTO reservation (name, number, email) VALUES (?, ?, ?)";
    connection.query(query, [name, phone, email], (err, results) => {
        if (err) {
            console.error(err);
            res.status(500).send("예약 추가 오류");
            return;
        }
        res.json({ message: "예약 추가 성공", id: results.insertId });
    });
});

const PORT = process.env.PORT || 3022;
app.listen(PORT, () => {
    console.log(`서버 실행 중: http://localhost:${PORT}`);
});
app.post("/api/reservations/add", (req, res) => {
    // 이제 req.body에는 { name, number, email }가 포함됩니다.
    const { name, number, email } = req.body;
    const query = "INSERT INTO reservation (name, number, email) VALUES (?, ?, ?)";
    connection.query(query, [name, number, email], (err, results) => {
        if (err) {
            console.error(err);
            res.status(500).send("예약 추가 오류");
            return;
        }
        res.json({ message: "예약 추가 성공", id: results.insertId });
    });
});

