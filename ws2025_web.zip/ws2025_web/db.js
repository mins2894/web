// db.js
const mysql = require("mysql2");

const connection = mysql.createConnection({
    host: "localhost",
    user: "root",       // 실제 사용자명으로 수정
    password: "1234",       // 실제 비밀번호로 수정
    database: "test"    // 사용하려는 데이터베이스 이름
});

connection.connect((err) => {
    if (err) {
        console.error("MySQL 연결 실패:", err);
        return;
    }
    console.log("MySQL 연결 성공");
});

module.exports = connection;
